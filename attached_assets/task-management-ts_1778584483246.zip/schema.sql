-- Neon SQL Schema for Task Management System
-- Run this in your Neon console or via psql

CREATE TABLE IF NOT EXISTS users (
  id         SERIAL PRIMARY KEY,
  full_name  VARCHAR(50)  NOT NULL,
  username   VARCHAR(50)  NOT NULL UNIQUE,
  password   VARCHAR(255) NOT NULL,
  role       VARCHAR(10)  NOT NULL CHECK (role IN ('admin', 'employee')),
  created_at TIMESTAMP    DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS tasks (
  id          SERIAL PRIMARY KEY,
  title       VARCHAR(100) NOT NULL,
  description TEXT,
  assigned_to INT REFERENCES users(id) ON DELETE SET NULL,
  due_date    DATE,
  status      VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed')),
  created_at  TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS notifications (
  id        SERIAL PRIMARY KEY,
  message   TEXT        NOT NULL,
  recipient INT         NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type      VARCHAR(50) NOT NULL,
  date      DATE        NOT NULL DEFAULT CURRENT_DATE,
  is_read   BOOLEAN     DEFAULT FALSE
);
