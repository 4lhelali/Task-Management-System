import { Request, Response, NextFunction } from 'express';

export function requireLogin(req: Request, res: Response, next: NextFunction): void {
  if (req.session.userId && req.session.role) {
    next();
  } else {
    res.redirect('/login?error=First login');
  }
}

export function requireAdmin(req: Request, res: Response, next: NextFunction): void {
  if (req.session.userId && req.session.role === 'admin') {
    next();
  } else {
    res.redirect('/login?error=Unauthorized');
  }
}

export function requireEmployee(req: Request, res: Response, next: NextFunction): void {
  if (req.session.userId && req.session.role === 'employee') {
    next();
  } else {
    res.redirect('/login?error=Unauthorized');
  }
}
