export type Role = 'admin' | 'employee';
export type TaskStatus = 'pending' | 'in_progress' | 'completed';

export interface User {
  id: number;
  full_name: string;
  username: string;
  password: string;
  role: Role;
  created_at: Date;
}

export interface Task {
  id: number;
  title: string;
  description: string | null;
  assigned_to: number | null;
  due_date: string | null;
  status: TaskStatus;
  created_at: Date;
}

export interface Notification {
  id: number;
  message: string;
  recipient: number;
  type: string;
  date: string;
  is_read: boolean;
}

// Extend express-session
declare module 'express-session' {
  interface SessionData {
    userId: number;
    username: string;
    role: Role;
  }
}
