import { sql } from '../db';
import { Notification } from '../types';

export async function getMyNotifications(userId: number): Promise<Notification[]> {
  const rows = await sql`SELECT * FROM notifications WHERE recipient = ${userId} ORDER BY id DESC`;
  return rows as Notification[];
}

export async function countUnreadNotifications(userId: number): Promise<number> {
  const rows = await sql`SELECT COUNT(*) as count FROM notifications WHERE recipient = ${userId} AND is_read = false`;
  return Number(rows[0].count);
}

export async function insertNotification(message: string, recipient: number, type: string): Promise<void> {
  await sql`INSERT INTO notifications (message, recipient, type, date) VALUES (${message}, ${recipient}, ${type}, CURRENT_DATE)`;
}

export async function markNotificationRead(notificationId: number, recipientId: number): Promise<void> {
  await sql`UPDATE notifications SET is_read = true WHERE id = ${notificationId} AND recipient = ${recipientId}`;
}
