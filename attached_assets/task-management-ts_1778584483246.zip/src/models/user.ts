import { sql } from '../db';
import { User } from '../types';

export async function getAllEmployees(): Promise<User[]> {
  const rows = await sql`SELECT * FROM users WHERE role = 'employee' ORDER BY id DESC`;
  return rows as User[];
}

export async function getUserById(id: number): Promise<User | null> {
  const rows = await sql`SELECT * FROM users WHERE id = ${id}`;
  return (rows[0] as User) ?? null;
}

export async function getUserByUsername(username: string): Promise<User | null> {
  const rows = await sql`SELECT * FROM users WHERE username = ${username}`;
  return (rows[0] as User) ?? null;
}

export async function insertUser(full_name: string, username: string, password: string, role: string): Promise<void> {
  await sql`INSERT INTO users (full_name, username, password, role) VALUES (${full_name}, ${username}, ${password}, ${role})`;
}

export async function updateUser(id: number, full_name: string, username: string, password: string): Promise<void> {
  await sql`UPDATE users SET full_name = ${full_name}, username = ${username}, password = ${password} WHERE id = ${id} AND role = 'employee'`;
}

export async function deleteUser(id: number): Promise<void> {
  await sql`DELETE FROM users WHERE id = ${id} AND role = 'employee'`;
}

export async function updateProfile(id: number, full_name: string, password: string): Promise<void> {
  await sql`UPDATE users SET full_name = ${full_name}, password = ${password} WHERE id = ${id}`;
}

export async function countEmployees(): Promise<number> {
  const rows = await sql`SELECT COUNT(*) as count FROM users WHERE role = 'employee'`;
  return Number(rows[0].count);
}
