import { sql } from '../db';
import { Task } from '../types';

export async function getAllTasks(): Promise<Task[]> {
  const rows = await sql`SELECT * FROM tasks ORDER BY id DESC`;
  return rows as Task[];
}

export async function getTasksDueToday(): Promise<Task[]> {
  const rows = await sql`SELECT * FROM tasks WHERE due_date = CURRENT_DATE AND status != 'completed' ORDER BY id DESC`;
  return rows as Task[];
}

export async function getTasksOverdue(): Promise<Task[]> {
  const rows = await sql`SELECT * FROM tasks WHERE due_date < CURRENT_DATE AND status != 'completed' ORDER BY id DESC`;
  return rows as Task[];
}

export async function getTasksNoDeadline(): Promise<Task[]> {
  const rows = await sql`SELECT * FROM tasks WHERE (due_date IS NULL OR due_date = '0001-01-01') AND status != 'completed' ORDER BY id DESC`;
  return rows as Task[];
}

export async function getTaskById(id: number): Promise<Task | null> {
  const rows = await sql`SELECT * FROM tasks WHERE id = ${id}`;
  return (rows[0] as Task) ?? null;
}

export async function getTasksByAssignedTo(userId: number): Promise<Task[]> {
  const rows = await sql`SELECT * FROM tasks WHERE assigned_to = ${userId} ORDER BY id DESC`;
  return rows as Task[];
}

export async function insertTask(title: string, description: string, assigned_to: number | null, due_date: string | null): Promise<void> {
  await sql`INSERT INTO tasks (title, description, assigned_to, due_date) VALUES (${title}, ${description}, ${assigned_to}, ${due_date})`;
}

export async function updateTask(id: number, title: string, description: string, assigned_to: number | null, due_date: string | null): Promise<void> {
  await sql`UPDATE tasks SET title = ${title}, description = ${description}, assigned_to = ${assigned_to}, due_date = ${due_date} WHERE id = ${id}`;
}

export async function updateTaskStatus(id: number, status: string): Promise<void> {
  await sql`UPDATE tasks SET status = ${status} WHERE id = ${id}`;
}

export async function deleteTask(id: number): Promise<void> {
  await sql`DELETE FROM tasks WHERE id = ${id}`;
}

// Count helpers
export async function countTasks(): Promise<number> {
  const rows = await sql`SELECT COUNT(*) as count FROM tasks`;
  return Number(rows[0].count);
}

export async function countTasksOverdue(): Promise<number> {
  const rows = await sql`SELECT COUNT(*) as count FROM tasks WHERE due_date < CURRENT_DATE AND status != 'completed'`;
  return Number(rows[0].count);
}

export async function countTasksDueToday(): Promise<number> {
  const rows = await sql`SELECT COUNT(*) as count FROM tasks WHERE due_date = CURRENT_DATE AND status != 'completed'`;
  return Number(rows[0].count);
}

export async function countTasksNoDeadline(): Promise<number> {
  const rows = await sql`SELECT COUNT(*) as count FROM tasks WHERE (due_date IS NULL OR due_date = '0001-01-01') AND status != 'completed'`;
  return Number(rows[0].count);
}

export async function countByStatus(status: string): Promise<number> {
  const rows = await sql`SELECT COUNT(*) as count FROM tasks WHERE status = ${status}`;
  return Number(rows[0].count);
}

// Employee-scoped counts
export async function countMyTasks(userId: number): Promise<number> {
  const rows = await sql`SELECT COUNT(*) as count FROM tasks WHERE assigned_to = ${userId}`;
  return Number(rows[0].count);
}

export async function countMyTasksOverdue(userId: number): Promise<number> {
  const rows = await sql`SELECT COUNT(*) as count FROM tasks WHERE due_date < CURRENT_DATE AND status != 'completed' AND assigned_to = ${userId}`;
  return Number(rows[0].count);
}

export async function countMyTasksNoDeadline(userId: number): Promise<number> {
  const rows = await sql`SELECT COUNT(*) as count FROM tasks WHERE assigned_to = ${userId} AND status != 'completed' AND (due_date IS NULL OR due_date = '0001-01-01')`;
  return Number(rows[0].count);
}

export async function countMyByStatus(userId: number, status: string): Promise<number> {
  const rows = await sql`SELECT COUNT(*) as count FROM tasks WHERE status = ${status} AND assigned_to = ${userId}`;
  return Number(rows[0].count);
}
