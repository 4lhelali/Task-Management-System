import { Router, Request, Response } from 'express';
import { requireAdmin, requireLogin } from '../middleware/auth';
import {
  getAllTasks, getTasksDueToday, getTasksOverdue, getTasksNoDeadline,
  getTaskById, getTasksByAssignedTo,
  insertTask, updateTask, updateTaskStatus, deleteTask,
  countTasks, countTasksDueToday, countTasksOverdue, countTasksNoDeadline
} from '../models/task';
import { getAllEmployees } from '../models/user';
import { insertNotification } from '../models/notification';

const router = Router();

// GET /tasks - Admin: all tasks with filter
router.get('/tasks', requireAdmin, async (req: Request, res: Response) => {
  const { due_date } = req.query;
  const { username, role } = req.session;
  try {
    let tasks, numTask: number, text = 'All Tasks';

    if (due_date === 'Due Today') {
      tasks = await getTasksDueToday();
      numTask = await countTasksDueToday();
      text = 'Due Today';
    } else if (due_date === 'Overdue') {
      tasks = await getTasksOverdue();
      numTask = await countTasksOverdue();
      text = 'Overdue';
    } else if (due_date === 'No Deadline') {
      tasks = await getTasksNoDeadline();
      numTask = await countTasksNoDeadline();
      text = 'No Deadline';
    } else {
      tasks = await getAllTasks();
      numTask = await countTasks();
    }

    const users = await getAllEmployees();
    res.render('tasks.html', { tasks, users, numTask, text, success: req.query.success, username, role });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
});

// GET /tasks/create
router.get('/tasks/create', requireAdmin, async (req: Request, res: Response) => {
  const users = await getAllEmployees();
  res.render('create-task.html', { users, error: req.query.error, success: req.query.success, username: req.session.username, role: req.session.role });
});

// POST /tasks/create
router.post('/tasks/create', requireAdmin, async (req: Request, res: Response) => {
  const { title, description, assigned_to, due_date } = req.body;
  if (!title) return res.redirect('/tasks/create?error=Title is required');
  try {
    const assignedId = assigned_to && assigned_to !== '0' ? Number(assigned_to) : null;
    const deadline = due_date || null;
    await insertTask(title, description || '', assignedId, deadline);
    if (assignedId) {
      await insertNotification(`New task assigned: ${title}`, assignedId, 'assignment');
    }
    res.redirect('/tasks/create?success=Task created successfully');
  } catch (err) {
    console.error(err);
    res.redirect('/tasks/create?error=Server error');
  }
});

// GET /tasks/:id/edit - Admin
router.get('/tasks/:id/edit', requireAdmin, async (req: Request, res: Response) => {
  const task = await getTaskById(Number(req.params.id));
  if (!task) return res.redirect('/tasks');
  const users = await getAllEmployees();
  res.render('edit-task.html', { task, users, error: req.query.error, success: req.query.success, username: req.session.username, role: req.session.role });
});

// POST /tasks/:id/edit
router.post('/tasks/:id/edit', requireAdmin, async (req: Request, res: Response) => {
  const { title, description, assigned_to, due_date } = req.body;
  const id = Number(req.params.id);
  try {
    const assignedId = assigned_to && assigned_to !== '0' ? Number(assigned_to) : null;
    await updateTask(id, title, description || '', assignedId, due_date || null);
    res.redirect(`/tasks?success=Task updated`);
  } catch (err) {
    console.error(err);
    res.redirect(`/tasks/${id}/edit?error=Server error`);
  }
});

// GET /tasks/:id/delete
router.get('/tasks/:id/delete', requireAdmin, async (req: Request, res: Response) => {
  await deleteTask(Number(req.params.id));
  res.redirect('/tasks?success=Task deleted');
});

// GET /my-tasks - Employee
router.get('/my-tasks', requireLogin, async (req: Request, res: Response) => {
  const tasks = await getTasksByAssignedTo(req.session.userId!);
  res.render('my-tasks.html', { tasks, success: req.query.success, username: req.session.username, role: req.session.role });
});

// GET /my-tasks/:id/edit - Employee edit status
router.get('/my-tasks/:id/edit', requireLogin, async (req: Request, res: Response) => {
  const task = await getTaskById(Number(req.params.id));
  if (!task || task.assigned_to !== req.session.userId) return res.redirect('/my-tasks');
  res.render('edit-task-employee.html', { task, error: req.query.error, success: req.query.success, username: req.session.username, role: req.session.role });
});

// POST /my-tasks/:id/edit
router.post('/my-tasks/:id/edit', requireLogin, async (req: Request, res: Response) => {
  const { status } = req.body;
  const id = Number(req.params.id);
  try {
    await updateTaskStatus(id, status);
    res.redirect('/my-tasks?success=Task updated');
  } catch (err) {
    res.redirect(`/my-tasks/${id}/edit?error=Server error`);
  }
});

export default router;
