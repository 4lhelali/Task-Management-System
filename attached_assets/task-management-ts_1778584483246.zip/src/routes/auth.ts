import { Router, Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { getUserByUsername, insertUser } from '../models/user';

const router = Router();

// GET /login
router.get('/login', (req: Request, res: Response) => {
  if (req.session.userId) return res.redirect('/');
  res.render('login.html', {
    error: req.query.error,
    success: req.query.success,
  });
});

// POST /login
router.post('/login', async (req: Request, res: Response) => {
  const { user_name, password } = req.body;
  try {
    const user = await getUserByUsername(user_name);
    if (!user) return res.redirect('/login?error=Invalid username or password');

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.redirect('/login?error=Invalid username or password');

    req.session.userId = user.id;
    req.session.username = user.username;
    req.session.role = user.role;
    res.redirect('/');
  } catch (err) {
    console.error(err);
    res.redirect('/login?error=Server error');
  }
});

// GET /signup
router.get('/signup', (req: Request, res: Response) => {
  if (req.session.userId) return res.redirect('/');
  res.render('signup.html', {
    error: req.query.error,
    success: req.query.success,
  });
});

// POST /signup
router.post('/signup', async (req: Request, res: Response) => {
  const { full_name, user_name, password, confirm_password, role } = req.body;
  if (password !== confirm_password) {
    return res.redirect('/signup?error=Passwords do not match');
  }
  try {
    const existing = await getUserByUsername(user_name);
    if (existing) return res.redirect('/signup?error=Username already taken');

    const hashed = await bcrypt.hash(password, 10);
    await insertUser(full_name, user_name, hashed, role || 'employee');
    res.redirect('/login?success=Account created! Please log in.');
  } catch (err) {
    console.error(err);
    res.redirect('/signup?error=Server error');
  }
});

// GET /logout
router.get('/logout', (req: Request, res: Response) => {
  req.session.destroy(() => {
    res.redirect('/signup');
  });
});

export default router;
