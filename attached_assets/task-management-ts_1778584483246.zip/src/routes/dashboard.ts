import { Router, Request, Response } from 'express';
import { requireLogin } from '../middleware/auth';
import {
  countTasks, countTasksOverdue, countTasksNoDeadline,
  countTasksDueToday, countByStatus,
  countMyTasks, countMyTasksOverdue, countMyTasksNoDeadline, countMyByStatus
} from '../models/task';
import { countEmployees } from '../models/user';

const router = Router();

router.get('/', requireLogin, async (req: Request, res: Response) => {
  const { userId, role, username } = req.session;
  try {
    let dashboardData: { label: string; count: number; icon: string }[] = [];

    if (role === 'admin') {
      const [employees, allTasks, overdue, noDeadline, dueToday, pending, inProgress, completed] = await Promise.all([
        countEmployees(),
        countTasks(),
        countTasksOverdue(),
        countTasksNoDeadline(),
        countTasksDueToday(),
        countByStatus('pending'),
        countByStatus('in_progress'),
        countByStatus('completed'),
      ]);
      dashboardData = [
        { label: 'Employees',   count: employees,  icon: 'fa-users' },
        { label: 'All Tasks',   count: allTasks,   icon: 'fa-tasks' },
        { label: 'Overdue',     count: overdue,    icon: 'fa-window-close-o' },
        { label: 'No Deadline', count: noDeadline, icon: 'fa-clock-o' },
        { label: 'Due Today',   count: dueToday,   icon: 'fa-exclamation-triangle' },
        { label: 'Notifications', count: overdue,  icon: 'fa-bell' },
        { label: 'Pending',     count: pending,    icon: 'fa-hourglass-start' },
        { label: 'In Progress', count: inProgress, icon: 'fa-spinner' },
        { label: 'Completed',   count: completed,  icon: 'fa-check-circle' },
      ];
    } else {
      const [myTasks, overdue, noDeadline, pending, inProgress, completed] = await Promise.all([
        countMyTasks(userId!),
        countMyTasksOverdue(userId!),
        countMyTasksNoDeadline(userId!),
        countMyByStatus(userId!, 'pending'),
        countMyByStatus(userId!, 'in_progress'),
        countMyByStatus(userId!, 'completed'),
      ]);
      dashboardData = [
        { label: 'My Tasks',    count: myTasks,    icon: 'fa-tasks' },
        { label: 'Overdue',     count: overdue,    icon: 'fa-window-close-o' },
        { label: 'No Deadline', count: noDeadline, icon: 'fa-clock-o' },
        { label: 'Pending',     count: pending,    icon: 'fa-hourglass-start' },
        { label: 'In Progress', count: inProgress, icon: 'fa-spinner' },
        { label: 'Completed',   count: completed,  icon: 'fa-check-circle' },
      ];
    }

    res.render('index.html', { dashboardData, role, username });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
});

export default router;
