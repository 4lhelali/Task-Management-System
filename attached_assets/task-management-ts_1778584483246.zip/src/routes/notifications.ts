import { Router, Request, Response } from 'express';
import { requireLogin } from '../middleware/auth';
import { getMyNotifications, countUnreadNotifications, markNotificationRead } from '../models/notification';

const router = Router();

// GET /notifications
router.get('/notifications', requireLogin, async (req: Request, res: Response) => {
  const notifications = await getMyNotifications(req.session.userId!);
  res.render('notifications.html', { notifications, username: req.session.username, role: req.session.role });
});

// API: GET /api/notification-count
router.get('/api/notification-count', requireLogin, async (req: Request, res: Response) => {
  const count = await countUnreadNotifications(req.session.userId!);
  res.json({ count });
});

// API: GET /api/notifications
router.get('/api/notifications', requireLogin, async (req: Request, res: Response) => {
  const notifications = await getMyNotifications(req.session.userId!);
  res.json(notifications);
});

// POST /api/notifications/:id/read
router.post('/api/notifications/:id/read', requireLogin, async (req: Request, res: Response) => {
  await markNotificationRead(Number(req.params.id), req.session.userId!);
  res.json({ ok: true });
});

export default router;
