import { Router, Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { requireAdmin, requireEmployee } from '../middleware/auth';
import { getAllEmployees, getUserById, insertUser, updateUser, deleteUser, updateProfile } from '../models/user';

const router = Router();

// GET /users
router.get('/users', requireAdmin, async (req: Request, res: Response) => {
  const users = await getAllEmployees();
  res.render('users.html', { users, success: req.query.success, username: req.session.username, role: req.session.role });
});

// GET /users/add
router.get('/users/add', requireAdmin, (req: Request, res: Response) => {
  res.render('add-user.html', { error: req.query.error, username: req.session.username, role: req.session.role });
});

// POST /users/add
router.post('/users/add', requireAdmin, async (req: Request, res: Response) => {
  const { full_name, user_name, password, role } = req.body;
  try {
    const hashed = await bcrypt.hash(password, 10);
    await insertUser(full_name, user_name, hashed, role || 'employee');
    res.redirect('/users?success=User added');
  } catch (err) {
    res.redirect('/users/add?error=Server error or username taken');
  }
});

// GET /users/:id/edit
router.get('/users/:id/edit', requireAdmin, async (req: Request, res: Response) => {
  const user = await getUserById(Number(req.params.id));
  if (!user) return res.redirect('/users');
  res.render('edit-user.html', { user, error: req.query.error, username: req.session.username, role: req.session.role });
});

// POST /users/:id/edit
router.post('/users/:id/edit', requireAdmin, async (req: Request, res: Response) => {
  const { full_name, user_name, password } = req.body;
  const id = Number(req.params.id);
  try {
    const hashed = password && password !== '**********' ? await bcrypt.hash(password, 10) : (await getUserById(id))!.password;
    await updateUser(id, full_name, user_name, hashed);
    res.redirect('/users?success=User updated');
  } catch (err) {
    res.redirect(`/users/${id}/edit?error=Server error`);
  }
});

// GET /users/:id/delete
router.get('/users/:id/delete', requireAdmin, async (req: Request, res: Response) => {
  await deleteUser(Number(req.params.id));
  res.redirect('/users?success=User deleted');
});

// GET /profile
router.get('/profile', requireEmployee, async (req: Request, res: Response) => {
  const user = await getUserById(req.session.userId!);
  res.render('profile.html', { user, username: req.session.username, role: req.session.role });
});

// GET /profile/edit
router.get('/profile/edit', requireEmployee, async (req: Request, res: Response) => {
  const user = await getUserById(req.session.userId!);
  res.render('edit-profile.html', { user, error: req.query.error, success: req.query.success, username: req.session.username, role: req.session.role });
});

// POST /profile/edit
router.post('/profile/edit', requireEmployee, async (req: Request, res: Response) => {
  const { full_name, password, new_password, confirm_password } = req.body;
  const userId = req.session.userId!;
  try {
    const user = await getUserById(userId);
    if (!user) return res.redirect('/login');
    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.redirect('/profile/edit?error=Current password is incorrect');
    if (new_password !== confirm_password) return res.redirect('/profile/edit?error=New passwords do not match');

    const hashed = await bcrypt.hash(new_password, 10);
    await updateProfile(userId, full_name, hashed);
    req.session.username = user.username;
    res.redirect('/profile/edit?success=Profile updated');
  } catch (err) {
    res.redirect('/profile/edit?error=Server error');
  }
});

export default router;
