import express from 'express';
import session from 'express-session';
import nunjucks from 'nunjucks';
import path from 'path';
import dotenv from 'dotenv';

import authRoutes from './routes/auth';
import dashboardRoutes from './routes/dashboard';
import taskRoutes from './routes/tasks';
import userRoutes from './routes/users';
import notificationRoutes from './routes/notifications';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Body parsing
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Static files
app.use(express.static(path.join(__dirname, '../public')));

// Nunjucks templating
nunjucks.configure(path.join(__dirname, '../views'), {
  autoescape: true,
  express: app,
  watch: true,
});
app.set('view engine', 'html');

// Session
app.use(session({
  secret: process.env.SESSION_SECRET || 'changeme',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 24 }, // 24h
}));

// Routes
app.use('/', authRoutes);
app.use('/', dashboardRoutes);
app.use('/', taskRoutes);
app.use('/', userRoutes);
app.use('/', notificationRoutes);

// 404
app.use((req, res) => res.status(404).send('Page not found'));

app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});
